ClassTracker app to assits students in tracking their class
