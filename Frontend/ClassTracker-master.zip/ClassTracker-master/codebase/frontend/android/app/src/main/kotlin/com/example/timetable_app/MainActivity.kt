package com.example.timetable_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
