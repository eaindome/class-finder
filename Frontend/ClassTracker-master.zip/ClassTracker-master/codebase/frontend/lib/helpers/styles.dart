import 'package:flutter/material.dart';

TextStyle sansMedium = const TextStyle(
  fontSize: 16,
  fontWeight: FontWeight.w500,
);
TextStyle sansBold = const TextStyle(
  fontSize: 16,
  fontWeight: FontWeight.bold,
);
TextStyle sansRegular = const TextStyle(
  fontSize: 14,
);
