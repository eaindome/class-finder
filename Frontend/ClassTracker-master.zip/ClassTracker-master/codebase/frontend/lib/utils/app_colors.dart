import 'package:flutter/material.dart';

class AppColors {
  static const Color secondary = Color.fromRGBO(248, 214, 218, 1);
  static const Color red = Color.fromRGBO(226, 24, 51, 1);
}
