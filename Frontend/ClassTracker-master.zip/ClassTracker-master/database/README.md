# Database
This describes a database in postgresql for the project

#
`models`

 - It describes the graphical representation using ER Model for the database

#
`database_queries`

 - It contains the queries for the database