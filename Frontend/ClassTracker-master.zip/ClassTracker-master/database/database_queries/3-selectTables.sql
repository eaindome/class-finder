SELECT * FROM programme
SELECT * FROM student
SELECT * FROM program_year 
SELECT * FROM course
SELECT * FROM room
SELECT * FROM program_course;
SELECT * FROM timetable
