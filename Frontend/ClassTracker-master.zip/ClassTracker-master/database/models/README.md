this describes the model diagram for the database
